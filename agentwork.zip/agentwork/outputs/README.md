# Outputs

Written by the pipeline agents — do not edit manually.

| File | Written by |
|------|-----------|
| `01-design.md` | `design` agent |
| `02-security-review.md` | `security-review` agent |
| `03-logic-validation.md` | `logic-validation` agent |
| `04-java/` | `java-generation` agent |
| `04-java/GENERATION-MANIFEST.md` | `java-generation` agent |
| `05-pipeline-report.md` | `pipeline-report` agent |
