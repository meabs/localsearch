# C++ to Java Migration Pipeline

A regulated, multi-agent GitHub Copilot pipeline that migrates a C++ file to
production-grade Java. Five specialist agents run in sequence, each gating the
next. Six skills provide scripted checks that the agents cannot reliably self-verify.

---

## How the pipeline works

```
You drop three files into inputs/
         │
         ▼
┌─────────────────────┐
│  cpp-to-java        │  ← invoke this agent to run the full pipeline
│  (orchestrator)     │
└────────┬────────────┘
         │ invokes in order
         ▼
┌─────────────────────┐   skill: cpp-interface-extract  (extracts public API mechanically)
│  1. design          │   skill: cpp-java-type-reference (authoritative type mapping table)
│                     │   → outputs/01-design.md
└────────┬────────────┘
         │ gate-enforcer checks for [GATE FAIL]
         ▼
┌─────────────────────┐   skill: gate-enforcer          (deterministic gate check)
│  2. security-review │   → outputs/02-security-review.md
│  (code only)        │
└────────┬────────────┘
         │ gate-enforcer checks for [GATE FAIL]
         ▼
┌─────────────────────┐   skill: gate-enforcer
│  3. logic-          │   skill: cpp-java-type-reference (validates type mapping coverage)
│     validation      │   → outputs/03-logic-validation.md
└────────┬────────────┘
         │ gate-enforcer checks for [GATE FAIL]
         ▼
┌─────────────────────┐   skill: gate-enforcer
│  4. java-           │   skill: regulated-java-patterns (12 copy-paste security patterns)
│     generation      │   skill: polyglot-test-generator (JUnit 5 tests after code is done)
│                     │   → outputs/04-java/
│                     │   → outputs/04-java-tests/
│                     │   → outputs/04-java/GENERATION-MANIFEST.md
└────────┬────────────┘
         │ gate-enforcer checks manifest
         ▼
┌─────────────────────┐   skill: gate-enforcer          (checks all four prior gates)
│  5. pipeline-report │   skill: java-compile-check     (runs javac; separates syntax
│                     │                                   errors from missing-dep errors)
│                     │   → outputs/05-pipeline-report.md
└─────────────────────┘
         │
         ▼
  PIPELINE VERDICT: READY FOR HUMAN REVIEW
              or
  PIPELINE VERDICT: BLOCKED (lists what failed)
```

### What each gate does

Every agent writes `[GATE FAIL — Agent N must not run]` at the top of its output file
if it cannot proceed. The `gate-enforcer` skill runs a deterministic `grep` check —
not an LLM read — so gate detection is reliable even on large output files.

### What the skills add

| Skill | What it does that the LLM cannot reliably do alone |
|-------|--------------------------------------------------|
| `cpp-interface-extract` | Runs `ctags` or regex to extract every public function mechanically — the LLM misses macro-generated and `extern "C"` functions |
| `java-compile-check` | Runs `javac` and distinguishes syntax errors (blocking) from missing-dependency errors (expected without Maven) |
| `gate-enforcer` | Deterministic `grep` for `[GATE FAIL]` — replaces LLM text interpretation of prior outputs |
| `cpp-java-type-reference` | 60+ type pairs with semantic differences — loaded from file rather than reconstructed from training data each run |
| `regulated-java-patterns` | 12 copy-paste security patterns (constant-time comparison, credential handling, etc.) — prevents drift between runs |
| `polyglot-test-generator` | Drives JUnit 5 test generation tied to the traceability matrix — tests become the interface preservation proof |

---

## Prerequisites

Install these before running the pipeline. The agents will still run without them
but quality degrades in specific ways noted below.

| Tool | Required? | What breaks without it | Install |
|------|-----------|----------------------|---------|
| **GitHub Copilot** (VS Code or github.com) | Required | Nothing works | [docs.github.com/copilot](https://docs.github.com/en/copilot) |
| **Python 3.8+** | Required | `cpp-interface-extract` and `java-compile-check` skills fail | `brew install python3` |
| **JDK 21+** (`javac`) | Required for compile check | `java-compile-check` returns `ERROR` status; no syntax validation | [adoptium.net](https://adoptium.net) |
| **Universal Ctags** | Strongly recommended | `cpp-interface-extract` falls back to regex; misses templates, macros, `extern "C"` | `brew install universal-ctags` |

Verify your setup:
```bash
python3 --version        # 3.8+
javac --version          # 21+
ctags --version          # should say "Universal Ctags"
```

---

## Quick start

### 1. Place your input files

```
inputs/
├── source.cpp              ← your C++ file
├── api-schema.yaml         ← OpenAPI / Protobuf / custom schema (or api-schema.json)
└── logic-document.md       ← business logic description
```

All three files must be present. The pipeline halts with `[PIPELINE HALT]` if any is missing.

### 2. Run the pipeline

**VS Code (Copilot agent mode):**
1. Open the Copilot Chat panel
2. Switch to **Agent** mode
3. Type: `@cpp-to-java run the full migration pipeline`

The `cpp-to-java` orchestrator invokes all five agents in sequence, runs the gate checks,
and reports the final verdict.

**GitHub.com (Copilot cloud agent / coding agent):**
1. Go to your repository → **Copilot** tab
2. Select the `cpp-to-java` agent
3. Describe the task: `Run the C++ to Java migration pipeline on the files in inputs/`

**GitHub CLI:**
```bash
gh copilot suggest "Run the cpp-to-java migration pipeline"
```

### 3. Check the result

Open `outputs/05-pipeline-report.md`. The second line is always the verdict:

```
PIPELINE VERDICT: READY FOR HUMAN REVIEW — all automated gates passed.
```
or
```
PIPELINE VERDICT: BLOCKED
Blocking conditions:
  1. ...
```

---

## Running individual agents

You can invoke each agent independently — useful for re-running a single step after
fixing a gate failure.

**VS Code:**
```
@design        analyse the C++ source and produce the Java architecture design
@security-review  review the design and C++ source for code-level security issues
@logic-validation  validate the C++ logic against the design and logic document
@java-generation   generate Java source files from the validated design
@pipeline-report   produce the final migration readiness report
```

**Important:** Each agent checks the prior gates before starting. If you re-run agent 3
(`logic-validation`) without fixing the agent 2 (`security-review`) gate failure, it
will halt immediately.

---

## Output files reference

| File | Contents |
|------|----------|
| `outputs/01-design.md` | Java architecture design, Interface Map, type mapping table |
| `outputs/02-security-review.md` | Code-level security findings, OWASP/CWE checklist, remediations for agent 4 |
| `outputs/03-logic-validation.md` | Traceability matrix, business rule coverage, logic discrepancies |
| `outputs/04-java/` | Generated Java source files |
| `outputs/04-java-tests/` | Generated JUnit 5 test files |
| `outputs/04-java/GENERATION-MANIFEST.md` | File list, coverage summary, open items |
| `outputs/compile-result.json` | javac output (written by pipeline-report; status: PASS / PASS_WITH_DEPENDENCY_ERRORS / FAIL) |
| `outputs/05-pipeline-report.md` | Final verdict, cross-agent consistency check, compliance checklist |
| `inputs/extracted-interface.json` | C++ public interface extracted by `cpp-interface-extract` (written during agent 1) |

---

## Should you set up hooks?

**Short answer:** one git hook is worth adding; a GitHub Actions workflow is worth
adding if this pipeline will run regularly. Nothing else is needed.

### Recommended: git pre-commit hook

Prevents accidental commits of generated output or input files containing secrets.

Create `.git/hooks/pre-commit`:

```bash
#!/usr/bin/env bash
# Block commits of pipeline outputs (they are derived artefacts, not source)
if git diff --cached --name-only | grep -q '^outputs/'; then
  echo "ERROR: outputs/ files should not be committed — they are generated artefacts."
  echo "Add outputs/ to .gitignore or unstage these files."
  exit 1
fi

# Warn if an input file looks like it might contain a secret
if git diff --cached --name-only | grep -q '^inputs/'; then
  if git diff --cached -- 'inputs/*' | grep -qiE '(password|secret|api[_-]?key|token)\s*[:=]'; then
    echo "WARNING: A file in inputs/ may contain a credential. Review before committing."
    echo "If intentional, commit with: git commit --no-verify"
    exit 1
  fi
fi
```

```bash
chmod +x .git/hooks/pre-commit
```

Add to `.gitignore`:
```
outputs/
inputs/extracted-interface.json
inputs/compile-result.json
```

### Optional: GitHub Actions workflow

Useful if you want the pipeline to run automatically when input files are updated
on a branch, or to run on a schedule for a large batch of files.

Create `.github/workflows/cpp-to-java.yml`:

```yaml
name: C++ to Java Migration

on:
  push:
    paths:
      - 'inputs/source.cpp'
      - 'inputs/api-schema.yaml'
      - 'inputs/api-schema.json'
      - 'inputs/logic-document.md'
  workflow_dispatch:   # allows manual trigger from the Actions tab

jobs:
  prerequisites:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Install Universal Ctags
        run: sudo apt-get install -y universal-ctags

      - name: Set up JDK 21
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '21'

      - name: Verify inputs present
        run: |
          for f in inputs/source.cpp inputs/logic-document.md; do
            [ -f "$f" ] || { echo "Missing: $f"; exit 1; }
          done
          ls inputs/api-schema.* > /dev/null 2>&1 || { echo "Missing: inputs/api-schema.*"; exit 1; }

      - name: Run gate-enforcer smoke test
        run: bash .github/skills/gate-enforcer/scripts/check-gate.sh inputs/source.cpp || true
        # Confirms the script is functional (source.cpp won't have GATE FAIL — exit 0 expected)

  # The Copilot agents themselves run interactively — this workflow only validates
  # prerequisites and input files. Trigger the agents manually or via Copilot CLI
  # after this job passes.
  notify:
    needs: prerequisites
    runs-on: ubuntu-latest
    steps:
      - name: Inputs ready
        run: echo "All inputs validated. Run the cpp-to-java agent to start the pipeline."
```

### Not needed: Claude Code hooks

The pipeline is entirely self-contained inside the Copilot agent files. Claude Code
hooks (`~/.claude/settings.json`) are not used by this pipeline and do not need to be
configured.

### Not needed: MCP servers

No MCP servers are required. The agents use only built-in tool aliases (`read`, `edit`,
`search`, `execute`, `agent`). If you want to extend the pipeline to post results to
Slack, Jira, or a custom system, an MCP server could be added to the `cpp-to-java`
orchestrator's frontmatter — but it is not part of the current design.

---

## Troubleshooting

**`[PIPELINE HALT] Missing required input`**
→ Check that all three files exist in `inputs/` with the exact names listed above.

**`gate-enforcer` script not found**
→ Run `bash .github/skills/gate-enforcer/scripts/check-gate.sh` from the repository root.
   If it fails, ensure you checked out the full repository including `.github/skills/`.

**`java-compile-check` returns `ERROR: javac not found`**
→ Install JDK 21+ and ensure `javac` is on your `PATH`. Run `javac --version` to confirm.
   The pipeline report will note this but the final verdict is based on prior gate results,
   not the compile check alone.

**`cpp-interface-extract` warns about regex fallback**
→ Install Universal Ctags: `brew install universal-ctags` (macOS) or `sudo apt-get install universal-ctags` (Linux).
   After installing, re-run agent 1 (`design`) — the extraction will be more complete.

**Agent stops at a gate with no output file written**
→ The agent likely hit its context or output limit before completing. Re-run the specific
   agent alone (not the orchestrator) and check the partial output file for clues.

**`PASS_WITH_DEPENDENCY_ERRORS` in compile-result.json**
→ This is expected. The generated Java references external API classes that are not
   available without Maven/Gradle resolving the dependency JARs. It means the code syntax
   is correct. Run a full `mvn compile` or `gradle compileJava` with the generated `pom.xml`
   or `build.gradle` (from the design) to do a full compile.

---

## Repository layout

```
.github/
├── copilot-instructions.md     ← global rules loaded into every agent automatically
├── agents/
│   ├── cpp-to-java.agent.md    ← orchestrator (start here)
│   ├── design.agent.md
│   ├── security-review.agent.md
│   ├── logic-validation.agent.md
│   ├── java-generation.agent.md
│   └── pipeline-report.agent.md
└── skills/
    ├── cpp-interface-extract/  ← SKILL.md + scripts/extract-interface.py
    ├── java-compile-check/     ← SKILL.md + scripts/compile-check.py
    ├── gate-enforcer/          ← SKILL.md + scripts/check-gate.sh
    ├── cpp-java-type-reference/← SKILL.md + type-mapping-reference.md
    ├── regulated-java-patterns/← SKILL.md + patterns-reference.md
    └── polyglot-test-generator/← SKILL.md + templates/junit5-migration-test.java
inputs/
└── README.md                   ← place source.cpp, api-schema.*, logic-document.md here
outputs/
└── README.md                   ← agents write here; do not edit manually
```
