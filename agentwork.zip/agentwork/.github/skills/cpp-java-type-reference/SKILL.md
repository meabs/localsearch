---
name: cpp-java-type-reference
description: Authoritative reference table mapping every standard C++ type to its Java equivalent, including semantic differences, overflow behaviour, nullability, encoding differences, and the required Java handling for each. Load this skill before building the type mapping table in the design agent or validating types in the logic-validation agent. Prevents the LLM from generating inconsistent or incomplete type mappings from training data alone.
---

# C++ to Java Type Reference

Load this skill before constructing the type mapping table in the design agent or validating type semantics in the logic-validation agent.

## When to use
- In `design` agent: read `type-mapping-reference.md` before writing Section 5 (Type Mapping Table). Use the entries in this file as the source of truth — do not generate the table from scratch.
- In `logic-validation` agent: cross-reference Part 5 (Type & Semantic Validation) against this file to ensure no type is missing or incorrectly mapped.

## How to use

Read the reference file:
```
.github/skills/cpp-java-type-reference/type-mapping-reference.md
```

For every C++ type found in `inputs/source.cpp`, locate its entry in the reference file and copy the Java type, semantic difference, and required handling into the design's type mapping table. If a type is not in the reference file, flag it explicitly and determine the mapping manually.

## Important notes

- The reference covers standard library types. Project-specific `typedef` aliases and custom types must be resolved to their underlying standard types first, then mapped.
- "Required handling" entries are mandatory — they are not optional guidance. Every item in that column must appear in either the design or the generated code.
- When a C++ type has platform-dependent size (e.g. `int`, `long`), the reference assumes the most common 64-bit Linux/Windows x86-64 ABI. If the target platform differs, flag the discrepancy.
