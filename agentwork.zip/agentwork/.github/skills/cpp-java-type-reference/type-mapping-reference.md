# C++ to Java Type Mapping Reference

## How to use this file
For every C++ type in `inputs/source.cpp`, locate its row below. Copy the Java Type,
Semantic Difference, and Required Handling into the design's type mapping table verbatim.
If a type is not listed, resolve it to its underlying standard type and look that up.

---

## 1. Fixed-Width Integer Types (`<cstdint>`)

| C++ Type | Java Type | Signed? | Overflow Behaviour | Required Handling |
|----------|-----------|---------|-------------------|-------------------|
| `int8_t` | `byte` | Signed | Wraps silently in both | No extra handling; document range: –128 to 127 |
| `uint8_t` | `short` | **Unsigned** | Java `byte` would be signed — use `short` | Validate ≥ 0 and ≤ 255 at external boundary; use `& 0xFF` when reading bytes |
| `int16_t` | `short` | Signed | Wraps silently in both | No extra handling |
| `uint16_t` | `int` | **Unsigned** | Use `int` to avoid sign issues | Validate ≥ 0 and ≤ 65535 at boundary |
| `int32_t` | `int` | Signed | Wraps silently in both | Use `Math.addExact`/`Math.multiplyExact` for untrusted arithmetic |
| `uint32_t` | `long` | **Unsigned** | Java `int` overflows at 2³¹ | **Must use `long`**; validate ≥ 0L and ≤ 4294967295L at boundary |
| `int64_t` | `long` | Signed | Wraps silently in both | Use `Math.addExact`/`Math.multiplyExact` for untrusted arithmetic |
| `uint64_t` | `long` | **Unsigned** | Java `long` is signed — values > 2⁶³−1 are negative | Use `Long.compareUnsigned`, `Long.toUnsignedString`; validate at boundary |
| `intptr_t` | `long` | Signed | Pointer-sized — always 8 bytes on 64-bit | Flag in design: pointer arithmetic patterns must be rethought |
| `uintptr_t` | `long` | **Unsigned** | As `uint64_t` | Flag in design: pointer arithmetic patterns must be rethought |
| `size_t` | `long` | **Unsigned** | On 64-bit: 8 bytes unsigned | Validate ≥ 0L; use `long` throughout |
| `ptrdiff_t` | `long` | Signed | Pointer difference — not meaningful in Java | Flag in design: must be replaced with index arithmetic |

---

## 2. Fundamental Integer Types (platform-dependent — assumes 64-bit x86-64 ABI)

| C++ Type | Typical Size | Java Type | Semantic Difference | Required Handling |
|----------|-------------|-----------|--------------------|--------------------|
| `bool` | 1 byte | `boolean` | Semantics match | None |
| `char` | 1 byte (signed or unsigned — implementation-defined) | `byte` or `char` | C++ `char` signedness is unspecified; Java `char` is 16-bit unsigned UTF-16 | If used for text: use Java `char` or `String`. If used as a byte: use `byte`; document the choice |
| `signed char` | 1 byte signed | `byte` | Matches (both signed) | None |
| `unsigned char` | 1 byte unsigned | `short` or `int` | Java `byte` is signed | Validate ≥ 0; use `& 0xFF` for bitwise operations |
| `short` / `short int` | 2 bytes signed | `short` | Matches | `Math.addExact` for untrusted arithmetic (promote to `int` first) |
| `unsigned short` | 2 bytes unsigned | `int` | Java `short` is signed | Validate ≥ 0 and ≤ 65535 |
| `int` | 4 bytes signed (on 64-bit) | `int` | Matches | `Math.addExact`/`Math.multiplyExact` for untrusted arithmetic |
| `unsigned int` | 4 bytes unsigned | `long` | **Use `long`** | Validate ≥ 0L and ≤ 4294967295L |
| `long` | 8 bytes on Linux/macOS 64-bit; 4 bytes on Windows 64-bit | `long` | Size differs on Windows! | Flag if code targets Windows; use `int64_t` in C++ source to be safe |
| `unsigned long` | 8 bytes Linux/macOS; 4 bytes Windows | `long` | As per `long` above + unsigned | Flag platform dependency; validate unsigned range |
| `long long` | 8 bytes signed | `long` | Matches | `Math.addExact`/`Math.multiplyExact` for untrusted arithmetic |
| `unsigned long long` | 8 bytes unsigned | `long` | Java `long` is signed | Use `Long.compareUnsigned`, `Long.toUnsignedString` |

---

## 3. Floating-Point Types

| C++ Type | Java Type | Semantic Difference | Required Handling |
|----------|-----------|--------------------|--------------------|
| `float` | `float` | IEEE 754 single — semantics match | Check for `Float.isNaN()` and `Float.isInfinite()` on external inputs |
| `double` | `double` | IEEE 754 double — semantics match | Check for `Double.isNaN()` and `Double.isInfinite()` on external inputs |
| `long double` | `double` | C++ `long double` is 80-bit extended on x86; Java has no equivalent | **Precision loss** — document explicitly; validate range fits `double` |

---

## 4. String & Character Types

| C++ Type | Java Type | Semantic Difference | Required Handling |
|----------|-----------|--------------------|--------------------|
| `std::string` | `String` | C++ allows arbitrary bytes; Java `String` is UTF-16 (internally) | Validate encoding at input boundary; use `StandardCharsets.UTF_8` explicitly when converting bytes |
| `std::string_view` | `String` (or `CharSequence`) | C++ non-owning view; Java `String` is immutable and owning | Java `String` is safe; no ownership concern |
| `const char*` | `String` | C-string (null-terminated); Java `String` is not null-terminated | Validate non-null before conversion; use `StandardCharsets.UTF_8` |
| `char*` (mutable) | `byte[]` or `StringBuilder` | Mutable buffer in C++; Java `String` is immutable | Use `byte[]` if mutation is required; `StringBuilder` for append-only |
| `std::wstring` | `String` | C++ wide string (UTF-16 or UTF-32, platform-dependent); Java `String` is UTF-16 | Validate encoding; may need `Charset.forName("UTF-32")` conversion |
| `std::string_view` (literal) | `String` literal | Compile-time vs. runtime — equivalent in Java | None |
| `char` (single char) | `char` | Java `char` is 16-bit unsigned UTF-16; C++ `char` may be 8-bit | If non-ASCII: use `int` code points; document encoding |

---

## 5. Smart Pointers & Optionality

| C++ Type | Java Type | Semantic Difference | Required Handling |
|----------|-----------|--------------------|--------------------|
| `T*` (raw pointer, nullable) | `@Nullable T` | C++ pointer can be null; Java reference can be null | Always annotate `@Nullable`; check before dereference |
| `T*` (raw pointer, non-null) | `T` | C++ may pass ownership; Java GC manages lifetime | Annotate `@NonNull`; document ownership transfer |
| `std::unique_ptr<T>` | `T` | C++ exclusive ownership; Java GC handles | Return directly; no wrapper needed. Document if move semantics matter |
| `std::shared_ptr<T>` | `T` | C++ reference-counted; Java GC handles | Return directly; no wrapper needed |
| `std::weak_ptr<T>` | `WeakReference<T>` | Semantics match | Use `WeakReference<T>`; handle `null` from `get()` |
| `std::optional<T>` | `Optional<T>` | Semantics match | **Never return `Optional<T>` containing `null`**; use `Optional.empty()` |
| `T&` (non-const ref param) | Return value or result wrapper | C++ out-parameter pattern | Convert to return value; if multiple outs, use a result record |
| `const T&` (const ref param) | `T` (passed by value) | Java passes object references; value types are copied | Pass object reference; document if defensive copy is needed |

---

## 6. Collection Types

| C++ Type | Java Type | Semantic Difference | Required Handling |
|----------|-----------|--------------------|--------------------|
| `std::vector<T>` | `List<T>` / `ArrayList<T>` | C++ contiguous memory; Java abstracted | Use `ArrayList<T>` for random access. Set initial capacity if size known |
| `std::array<T, N>` | `T[]` or `List<T>` | C++ fixed-size stack array; Java array is heap-allocated | Use `T[]` for fixed-size; document size constant |
| `std::deque<T>` | `ArrayDeque<T>` | C++ double-ended queue; Java `ArrayDeque` matches | Use `ArrayDeque<T>` |
| `std::list<T>` | `LinkedList<T>` | C++ doubly-linked list; Java `LinkedList` matches | Use `LinkedList<T>`; prefer `ArrayList` unless bidirectional iteration needed |
| `std::set<T>` | `TreeSet<T>` | C++ sorted, unique; Java `TreeSet` matches | Confirm element ordering is preserved |
| `std::unordered_set<T>` | `HashSet<T>` | C++ hash-based, unordered; Java `HashSet` matches | Ensure `hashCode()` + `equals()` implemented on element type |
| `std::multiset<T>` | `TreeMap<T, Integer>` (count as value) | C++ allows duplicates sorted; Java has no direct equivalent | Use `TreeMap` with frequency count; document the change |
| `std::map<K, V>` | `TreeMap<K, V>` | C++ sorted by key; Java `TreeMap` matches | Confirm key ordering preserved |
| `std::unordered_map<K, V>` | `HashMap<K, V>` | C++ hash-based; Java `HashMap` matches | Ensure `hashCode()` + `equals()` on key type |
| `std::multimap<K, V>` | `TreeMap<K, List<V>>` | C++ multiple values per key; Java has no direct equivalent | Use `Map<K, List<V>>`; document the change |
| `std::stack<T>` | `Deque<T>` (as stack) | C++ LIFO adapter; Java `Deque` used as stack | Use `ArrayDeque<T>`; use `push`/`pop` methods |
| `std::queue<T>` | `Queue<T>` / `ArrayDeque<T>` | C++ FIFO adapter; Java `Queue` matches | Use `ArrayDeque<T>` |
| `std::priority_queue<T>` | `PriorityQueue<T>` | C++ max-heap; Java `PriorityQueue` is min-heap by default | **Order reversed** — use `Comparator.reverseOrder()` to match C++ max-heap |
| `std::pair<A, B>` | `Map.Entry<A, B>` or a custom record | C++ two-element tuple; Java has no built-in pair | Define a `record Pair<A, B>(A first, B second)` — do not use `Map.Entry` as a general tuple |
| `std::tuple<...>` | Custom `record` | C++ heterogeneous tuple; Java has no built-in | Define a named `record` — meaningful names improve readability |

---

## 7. Concurrency Primitives

| C++ Type | Java Type | Semantic Difference | Required Handling |
|----------|-----------|--------------------|--------------------|
| `std::thread` | `Thread` or `ExecutorService` | C++ POSIX-like thread; Java thread | Prefer `ExecutorService` over raw `Thread`; document thread lifecycle |
| `std::mutex` | `ReentrantLock` or `synchronized` | C++ non-recursive by default; Java `synchronized` is reentrant | Use `ReentrantLock` for explicit lock/unlock; use `synchronized` for simple blocks |
| `std::recursive_mutex` | `ReentrantLock` | Both reentrant | Use `ReentrantLock` |
| `std::shared_mutex` | `ReadWriteLock` / `ReentrantReadWriteLock` | C++ shared/exclusive; Java `ReadWriteLock` matches | Use `ReentrantReadWriteLock` |
| `std::condition_variable` | `Condition` (from `ReentrantLock`) | Semantics match | Use `lock.newCondition()`; call in try/finally with lock |
| `std::atomic<T>` | `AtomicInteger` / `AtomicLong` / `AtomicReference<T>` | C++ lock-free guarantee; Java atomic classes are lock-free on most JVMs | Use the matching `java.util.concurrent.atomic` class; document memory ordering requirements |
| `std::atomic_flag` | `AtomicBoolean` | C++ guaranteed lock-free; Java `AtomicBoolean` matches | Use `AtomicBoolean` |
| `std::future<T>` | `Future<T>` / `CompletableFuture<T>` | C++ one-shot; Java `CompletableFuture` is chainable | Prefer `CompletableFuture<T>` for composability |
| `std::promise<T>` | `CompletableFuture<T>` | C++ producer side of future; Java `CompletableFuture` serves both roles | Use `CompletableFuture<T>` as both promise and future |
| `std::once_flag` + `std::call_once` | Double-checked locking or `static` initialiser | C++ lazy init; Java `static` fields are thread-safe via class loading | Use a `static final` holder class for lazy singleton init |

---

## 8. Error & Exception Types

| C++ Type | Java Type | Semantic Difference | Required Handling |
|----------|-----------|--------------------|--------------------|
| Return code (`int`, `bool`) | Custom exception class | C++ error-as-value; Java throws | Create a custom `RuntimeException` subclass; preserve the original return code as `errorCode` field |
| `std::exception` | `RuntimeException` | C++ base exception; Java `RuntimeException` equivalent | Extend `RuntimeException`; preserve `what()` message |
| `std::runtime_error` | `RuntimeException` | Semantics match | Extend `RuntimeException` |
| `std::logic_error` | `IllegalStateException` or `IllegalArgumentException` | C++ for precondition violations; Java equivalents | Choose based on whether the caller or the state is wrong |
| `std::invalid_argument` | `IllegalArgumentException` | Semantics match | Use directly |
| `std::out_of_range` | `IndexOutOfBoundsException` | Semantics match | Use directly |
| `std::overflow_error` | `ArithmeticException` | Semantics match | Use `Math.addExact` which throws `ArithmeticException` |
| `std::bad_alloc` | `OutOfMemoryError` | Both signal allocation failure | Do not catch `OutOfMemoryError` in library code |
| `errno` | Exception with error code | C++ thread-local error code; Java exception chain | Map each `errno` value to a custom exception; preserve the `errno` value as `errorCode` field |
| `std::error_code` | Custom exception with `errorCode` field | C++ structured error; Java exception | Map category + code to a custom exception hierarchy |

---

## 9. Utility & Other Types

| C++ Type | Java Type | Semantic Difference | Required Handling |
|----------|-----------|--------------------|--------------------|
| `std::variant<T...>` | Sealed interface with `record` implementations | C++ tagged union; Java sealed types match | Define `sealed interface` with one `record` per variant type |
| `std::any` | `Object` | C++ type-erased container; Java `Object` is the base of all types | Avoid `Object` in public API; prefer sealed interfaces or generics |
| `std::function<R(Args...)>` | `java.util.function.*` (e.g. `Function<T,R>`, `Predicate<T>`) | C++ general callable; Java functional interfaces | Map to the closest `java.util.function` interface; define a custom `@FunctionalInterface` if no match |
| `std::chrono::duration` | `java.time.Duration` | Semantics similar | Use `Duration` throughout; convert nanoseconds at the boundary |
| `std::chrono::time_point` | `java.time.Instant` | Semantics similar | Use `Instant` throughout |
| `std::filesystem::path` | `java.nio.file.Path` | Semantics similar | Use `Path`; never `String` for file paths; validate with `Path.normalize()` |
| `FILE*` | `InputStream` / `OutputStream` | C++ C-style file handle; Java stream abstraction | Wrap in try-with-resources; use `BufferedInputStream`/`BufferedOutputStream` |
| `void*` | `Object` or `byte[]` | C++ generic pointer; Java type-erased | Avoid in public API; determine actual type from context |
| `nullptr` | `null` / `Optional.empty()` | C++ null pointer; Java null | Prefer `Optional.empty()` for return values; annotate params with `@Nullable` |
| `enum` (unscoped) | `enum` | C++ unscoped enum pollutes namespace; Java enum is namespaced | Java enum values are automatically namespaced — no collision risk |
| `enum class` (scoped) | `enum` | Semantics match | Use Java `enum` directly |
