# Regulated Java Patterns Reference

Copy these patterns verbatim into generated code. Adapt only variable names, types,
and exception class names — do not alter the security-critical structural elements.
Every pattern includes a "WRONG" example showing the anti-pattern to avoid.

---

## P-001 — Constant-Time Secret Comparison

Use when comparing passwords, HMACs, API tokens, or any value where a timing
difference would leak information to an attacker.

```java
// [P-001] Constant-time comparison — prevents timing oracle (CWE-208)
import java.security.MessageDigest;

private static boolean secretEquals(byte[] a, byte[] b) {
    return MessageDigest.isEqual(a, b);
}

// For String secrets: convert to bytes with a fixed encoding first
private static boolean secretEquals(String a, String b) {
    return MessageDigest.isEqual(
        a.getBytes(StandardCharsets.UTF_8),
        b.getBytes(StandardCharsets.UTF_8)
    );
}
```

**WRONG — do not use:**
```java
// timing leak: short-circuits on first mismatch
if (token.equals(storedToken)) { ... }
if (token == storedToken) { ... }
```

---

## P-002 — Credential Handling with char[]

Use for any credential (password, API key, secret token) that must not linger in
the JVM string pool after use.

```java
// [P-002] Credential handling — char[] cleared after use (CWE-312)
import java.util.Arrays;

char[] credential = config.getApiKey();  // returns char[], not String
try {
    // use credential here — convert to bytes for a specific operation
    byte[] credentialBytes = new String(credential).getBytes(StandardCharsets.UTF_8);
    try {
        // use credentialBytes
    } finally {
        Arrays.fill(credentialBytes, (byte) 0);
    }
} finally {
    Arrays.fill(credential, '\0');  // zero out in-memory credential
}
```

**Configuration class field:**
```java
// [P-002] Store credentials as char[], not String
private char[] apiKey;

public char[] getApiKey() {
    return Arrays.copyOf(apiKey, apiKey.length);  // return a copy, not the field
}
```

**WRONG — do not use:**
```java
private String apiKey;           // String is interned; GC non-deterministic
String key = config.getKey();    // stays in string pool indefinitely
```

---

## P-003 — SLF4J Parameterised Logging

Use for every log statement. Never concatenate strings in log calls.

```java
// [P-003] Parameterised logging — prevents log injection (CWE-117)
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

private static final Logger log = LoggerFactory.getLogger(MyClass.class);

// Correct — lazy evaluation, no injection risk
log.debug("Processing request id={} type={}", requestId, requestType);
log.info("Response status={} duration={}ms", status, durationMs);
log.warn("Retrying attempt={} of maxAttempts={}", attempt, maxAttempts);
log.error("Operation failed for id={}: {}", id, ex.getMessage(), ex);
```

**WRONG — do not use:**
```java
log.info("Processing " + requestId + " type " + requestType);  // injection + performance
log.error("Error: " + ex);                                      // string concat
System.out.println("Processing: " + requestId);                 // stdout, never in prod
```

**Masking sensitive fields:**
```java
// [P-003] Never log credential values — log a masked indicator only
log.debug("Auth header present={}", authHeader != null ? "YES" : "NO");
log.debug("Request user={} token=***", userId);  // literal *** — not the value
```

---

## P-004 — SecureRandom

Use for all security-sensitive random values (tokens, nonces, salts, IDs used in auth).

```java
// [P-004] Cryptographically secure randomness (CWE-338)
import java.security.SecureRandom;

// Singleton — SecureRandom is thread-safe
private static final SecureRandom SECURE_RANDOM = new SecureRandom();

// Generate a random token (e.g. 32 bytes = 256 bits)
public static String generateToken() {
    byte[] bytes = new byte[32];
    SECURE_RANDOM.nextBytes(bytes);
    return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
}

// Generate a random int in range [0, bound)
public static int secureRandomInt(int bound) {
    return SECURE_RANDOM.nextInt(bound);
}
```

**WRONG — do not use for security purposes:**
```java
Math.random()            // not cryptographically secure
new Random()             // seeded from current time — predictable
new Random(42)           // fixed seed — fully predictable
ThreadLocalRandom.current()  // not cryptographically secure
```

---

## P-005 — Jackson ObjectMapper Hardening

Use this exact configuration for every `ObjectMapper` instance that processes external
(untrusted) JSON input.

```java
// [P-005] Jackson hardening — prevents insecure deserialisation (CWE-502)
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;

public static ObjectMapper createSecureMapper() {
    return JsonMapper.builder()
        // Reject unknown fields — prevents gadget-chain attacks
        .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true)
        // Reject numeric values for enum fields
        .configure(DeserializationFeature.FAIL_ON_NUMBERS_FOR_ENUMS, true)
        // Reject trailing tokens after valid JSON
        .configure(DeserializationFeature.FAIL_ON_TRAILING_TOKENS, true)
        // Do NOT enable default typing (polymorphic deserialisation)
        // .activateDefaultTyping(...)  ← NEVER enable this for untrusted input
        .build();
}
```

**WRONG — do not use:**
```java
new ObjectMapper()  // default config: FAIL_ON_UNKNOWN_PROPERTIES is false
mapper.activateDefaultTyping(...)  // CRITICAL: enables arbitrary class deserialisation
mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
```

---

## P-006 — Input Validation with ValidationResult

Use at every external input boundary (API responses, configuration values, user input).
Return all failures, not just the first.

```java
// [P-006] Input validation — accumulate all failures (CWE-20)
public record ValidationResult(boolean valid, List<String> failures) {

    public static ValidationResult ok() {
        return new ValidationResult(true, List.of());
    }

    public static ValidationResult of(List<String> failures) {
        return new ValidationResult(failures.isEmpty(), List.of(failures));
    }

    public void throwIfInvalid(String context) {
        if (!valid) {
            throw new ValidationException(context + ": " + String.join("; ", failures));
        }
    }
}

public ValidationResult validate(ExternalRequest request) {
    List<String> failures = new ArrayList<>();

    if (request.name() == null || request.name().isBlank()) {
        failures.add("name: must not be blank");
    } else if (request.name().length() > 255) {
        failures.add("name: must not exceed 255 characters");
    }

    if (request.amount() < 0 || request.amount() > MAX_AMOUNT) {
        failures.add("amount: must be between 0 and " + MAX_AMOUNT);
    }

    return ValidationResult.of(failures);
}
```

**WRONG — do not use:**
```java
if (!isValid(input)) throw new Exception("invalid");  // single failure, loses detail
boolean valid = validate(input);                       // callers may ignore boolean
```

---

## P-007 — Try-with-Resources (Correct Ordering)

Use for every `Closeable` / `AutoCloseable` resource. Order matters: resources are
closed in reverse declaration order.

```java
// [P-007] Try-with-resources — deterministic resource release (CWE-400)

// Single resource
try (InputStream in = Files.newInputStream(path)) {
    // use in
}  // in.close() called here even if exception thrown

// Multiple resources — closed in reverse order (stream first, then connection)
try (Connection conn = dataSource.getConnection();
     PreparedStatement stmt = conn.prepareStatement(sql);
     ResultSet rs = stmt.executeQuery()) {
    while (rs.next()) {
        // process
    }
}

// Nested try-with-resources for independent resources
try (InputStream in = openInput();
     OutputStream out = openOutput()) {
    // both closed even if processing fails mid-way
    transfer(in, out);
}
```

**WRONG — do not use:**
```java
InputStream in = Files.newInputStream(path);
try {
    // use in
} finally {
    in.close();  // closes — but if in is null (constructor threw), this throws NPE
}

// Resource leak: exception between open and try
InputStream in = Files.newInputStream(path);  // may succeed
OutputStream out = Files.newOutputStream(out); // if this throws, in leaks
try { ... } finally { in.close(); out.close(); }
```

---

## P-008 — Immutable Value Object (Record)

Use for all data carriers that cross service or thread boundaries.

```java
// [P-008] Immutable value object — thread-safe, no defensive copy needed
public record TransactionRequest(
    String transactionId,    // @NonNull — records do not allow null by default
    long amountCents,
    String currency,
    Instant timestamp
) {
    // Compact constructor for validation
    public TransactionRequest {
        Objects.requireNonNull(transactionId, "transactionId");
        if (transactionId.isBlank()) throw new IllegalArgumentException("transactionId must not be blank");
        if (amountCents < 0) throw new IllegalArgumentException("amountCents must be >= 0");
        Objects.requireNonNull(currency, "currency");
        if (currency.length() != 3) throw new IllegalArgumentException("currency must be 3-letter ISO code");
        Objects.requireNonNull(timestamp, "timestamp");
    }
}
```

**WRONG — do not use for shared data:**
```java
public class TransactionRequest {
    public String transactionId;  // public mutable field — not thread-safe
    public long amountCents;
    // no validation — partially constructed objects can be used
}
```

---

## P-009 — Custom Exception Hierarchy

Use this pattern for all custom exceptions in the migration. Every exception carries
the original C++ error code as a machine-readable field.

```java
// [P-009] Custom exception with error code — preserves C++ error codes
public class MigrationException extends RuntimeException {

    private final String errorCode;

    public MigrationException(String errorCode, String message) {
        super(message);
        this.errorCode = Objects.requireNonNull(errorCode, "errorCode");
    }

    public MigrationException(String errorCode, String message, Throwable cause) {
        super(message, cause);
        this.errorCode = Objects.requireNonNull(errorCode, "errorCode");
    }

    public String getErrorCode() {
        return errorCode;
    }

    // Override to ensure no internal state leaks in the message
    @Override
    public String getMessage() {
        return "[" + errorCode + "] " + super.getMessage();
    }
}

// Domain-specific subclass — map from C++ error enum value
public class RequestValidationException extends MigrationException {
    // C++ error: ERR_INVALID_REQUEST = 1001
    public RequestValidationException(String detail) {
        super("ERR_INVALID_REQUEST", "Request validation failed: " + detail);
    }
}
```

**WRONG — do not use:**
```java
throw new RuntimeException("something went wrong");  // no error code, no structure
throw new Exception(ex.getMessage());               // swallows stack trace, exposes internals
```

---

## P-010 — HTTP Client Timeout Configuration

Use for every HTTP client that calls an external API. Both timeouts are required.

```java
// [P-010] HTTP client with mandatory timeouts — prevents thread hangs (CWE-400)
import java.net.http.HttpClient;
import java.time.Duration;

public HttpClient buildHttpClient(ApiConfig config) {
    return HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(config.connectTimeoutSeconds()))
        .build();
    // Note: per-request read timeout is set on the HttpRequest, not the client
}

public HttpRequest buildRequest(URI uri, ApiConfig config) {
    return HttpRequest.newBuilder()
        .uri(uri)
        .timeout(Duration.ofSeconds(config.readTimeoutSeconds()))
        .GET()
        .build();
}
```

**Configuration class (required):**
```java
// [P-010] Timeouts must be configurable — not hard-coded
@ConfigurationProperties(prefix = "api.client")
public record ApiConfig(
    @Min(1) @Max(60) int connectTimeoutSeconds,
    @Min(1) @Max(300) int readTimeoutSeconds,
    @Min(1) @Max(10) int maxRetryAttempts
) {}
```

**WRONG — do not use:**
```java
HttpClient.newHttpClient()  // no connect timeout — thread can hang indefinitely
// or
.connectTimeout(Duration.ofSeconds(30))  // hard-coded — not configurable
```

---

## P-011 — Retry with Exponential Backoff and Jitter

Use for all retryable API calls. Unbounded retry loops are a DoS vector.

```java
// [P-011] Bounded retry with exponential backoff + jitter (CWE-400)
import java.time.Duration;
import java.util.concurrent.ThreadLocalRandom;

public <T> T withRetry(Supplier<T> operation, RetryConfig config) {
    Exception lastException = null;
    for (int attempt = 1; attempt <= config.maxAttempts(); attempt++) {
        try {
            return operation.get();
        } catch (RetryableException ex) {
            lastException = ex;
            if (attempt == config.maxAttempts()) break;

            long baseDelayMs = config.baseDelayMs() * (1L << (attempt - 1));  // exponential
            long cappedDelayMs = Math.min(baseDelayMs, config.maxDelayMs());
            long jitterMs = ThreadLocalRandom.current().nextLong(0, cappedDelayMs / 2 + 1);
            long sleepMs = cappedDelayMs + jitterMs;

            log.warn("Attempt {} of {} failed; retrying in {}ms: {}",
                attempt, config.maxAttempts(), sleepMs, ex.getMessage());
            try {
                Thread.sleep(sleepMs);
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                throw new MigrationException("ERR_INTERRUPTED", "Retry interrupted", ie);
            }
        }
    }
    throw new MigrationException("ERR_MAX_RETRIES",
        "Operation failed after " + config.maxAttempts() + " attempts", lastException);
}
```

**WRONG — do not use:**
```java
while (true) { try { return call(); } catch (Exception e) { } }  // infinite loop
// or
for (int i = 0; i < 3; i++) { Thread.sleep(1000); }  // fixed delay, no jitter
```

---

## P-012 — Arithmetic on Untrusted Values (Overflow-Safe)

Use when performing arithmetic on values received from external sources.

```java
// [P-012] Overflow-safe arithmetic for untrusted values (CWE-190)
import java.math.BigInteger;

// For addition, subtraction, multiplication — throw on overflow
long result = Math.addExact(a, b);
long result = Math.subtractExact(a, b);
long result = Math.multiplyExact(a, b);
int result  = Math.toIntExact(longValue);  // throws if doesn't fit in int

// For division — check divisor is not zero first
if (divisor == 0) throw new MigrationException("ERR_DIVIDE_BY_ZERO", "Division by zero");
long result = Math.floorDiv(a, divisor);  // consistent rounding for negative values

// For very large values where overflow is possible — use BigInteger
BigInteger big = BigInteger.valueOf(a).multiply(BigInteger.valueOf(b));
if (big.bitLength() > 63) throw new MigrationException("ERR_OVERFLOW", "Value out of range");
long result = big.longValueExact();
```

**WRONG — do not use for untrusted values:**
```java
long result = a + b;    // silently overflows
int result = (int) l;   // silently truncates
```
