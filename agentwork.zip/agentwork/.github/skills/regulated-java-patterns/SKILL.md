---
name: regulated-java-patterns
description: A reference card of exact, copy-paste-ready Java code patterns for regulated-environment requirements: constant-time secret comparison, credential handling with char arrays, SLF4J parameterised logging, SecureRandom usage, Jackson hardening, input validation, try-with-resources ordering, immutable value objects, and the standard exception hierarchy pattern. Load this skill before generating any Java code to ensure security-critical patterns are applied consistently and not reconstructed from LLM training data.
---

# Regulated Java Patterns Reference

Load this skill before generating Java source files in the `java-generation` agent.

## When to use
- In `java-generation` agent: read `patterns-reference.md` before writing any class. When the code requires one of the listed patterns, copy it verbatim rather than generating from scratch.
- When a `[SEC-REM-nnn]` remediation references a pattern type (e.g. "use constant-time comparison"), look it up here first.

## How to use

Read the reference file:
```
.github/skills/regulated-java-patterns/patterns-reference.md
```

Locate the relevant pattern by its heading. Copy the pattern into the generated Java file, adapting only variable names and types — do not alter the security-critical structural elements (timing, resource ordering, null guards).

## Important notes

- These patterns have been reviewed for regulated environments. Do not simplify them — the verbosity is intentional.
- Every pattern includes a "What NOT to do" example. When reviewing generated code, scan for those anti-patterns explicitly.
- If a pattern does not exist in this reference for a given `[SEC-REM-nnn]`, flag the gap and apply the most conservative implementation you can, then add `// [PATTERN-GAP: no reference pattern for SEC-REM-nnn]` inline.
