---
name: java-compile-check
description: Runs javac on all generated Java files in outputs/04-java/ and writes a structured JSON report to outputs/compile-result.json. Distinguishes syntax errors (blocking — the code is broken) from missing-dependency errors (expected when running without Maven/Gradle and external JARs). Use this skill in the pipeline-report agent to provide an objective compilation gate.
---

# Java Compilation Check

Use this skill in the `pipeline-report` agent after reading all prior outputs, before issuing the final verdict.

## When to use
Always — as the first action in the pipeline-report agent, before the cross-agent consistency check.

## How to use

Run the compilation check:
```
python3 .github/skills/java-compile-check/scripts/compile-check.py outputs/04-java outputs/compile-result.json
```

The script will print a summary line and write the full result to `outputs/compile-result.json`.

## Reading the output

Read `outputs/compile-result.json` after the script completes:

```json
{
  "status": "PASS | PASS_WITH_DEPENDENCY_ERRORS | FAIL | ERROR",
  "file_count": 12,
  "syntax_error_count": 0,
  "missing_dependency_error_count": 3,
  "warning_count": 1,
  "note": "3 errors are missing external dependencies (expected). No syntax errors.",
  "errors": [
    { "file": "...", "line": 42, "level": "error", "message": "cannot find symbol", "category": "dependency" }
  ],
  "warnings": [...]
}
```

## Gate interpretation

| Status | Meaning | Pipeline action |
|--------|---------|----------------|
| `PASS` | Compiled cleanly | Proceed |
| `PASS_WITH_DEPENDENCY_ERRORS` | Syntax correct; only missing external JARs | Proceed — note in report |
| `FAIL` | One or more syntax errors | **BLOCKED** — list errors in pipeline report |
| `ERROR` | javac not found or no .java files | **BLOCKED** — note the setup issue |

## Important notes

- `FAIL` is a blocking condition for the final pipeline verdict. List every syntax error in `outputs/05-pipeline-report.md` Section 3.4.
- `PASS_WITH_DEPENDENCY_ERRORS` is **not** blocking — external APIs cannot be resolved without the full build system. Note the count in the metrics table.
- If `status` is `ERROR` because javac is not found, add `[PIPELINE-INTEGRITY-FAILURE] javac not available` to the report but do not let it override a `PASS` or `FAIL` result from any prior step.
