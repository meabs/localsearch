#!/usr/bin/env python3
"""
Java compilation check for the C++ to Java migration pipeline.

Finds all .java files in the target directory, runs javac on them together,
and writes a structured JSON report distinguishing syntax errors (blocking)
from missing-dependency errors (expected without Maven/Gradle).

Usage:
    python3 compile-check.py [java_dir] [output_file]

Defaults:
    java_dir    = outputs/04-java
    output_file = outputs/compile-result.json
"""

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path


# Patterns that indicate a missing external dependency rather than a syntax error
DEPENDENCY_PATTERNS = [
    r"cannot find symbol",
    r"package .+ does not exist",
    r"error: package",
    r"symbol:\s+class",
    r"symbol:\s+variable",
]


def find_javac() -> str | None:
    javac = shutil.which("javac")
    if javac:
        return javac
    java_home = os.environ.get("JAVA_HOME", "")
    if java_home:
        candidate = os.path.join(java_home, "bin", "javac")
        if os.path.isfile(candidate):
            return candidate
    return None


def find_java_files(java_dir: str) -> list[str]:
    result = []
    for root, _, files in os.walk(java_dir):
        for f in files:
            if f.endswith(".java"):
                result.append(os.path.join(root, f))
    return sorted(result)


def is_dependency_error(message: str) -> bool:
    return any(re.search(p, message, re.IGNORECASE) for p in DEPENDENCY_PATTERNS)


def parse_javac_output(raw: str) -> tuple[list[dict], list[dict]]:
    errors, warnings = [], []
    # javac error format:  /path/to/File.java:42: error: some message
    pattern = re.compile(r"^(.+\.java):(\d+):\s+(error|warning):\s+(.+)$", re.MULTILINE)
    for m in pattern.finditer(raw):
        entry = {
            "file": m.group(1),
            "line": int(m.group(2)),
            "level": m.group(3),
            "message": m.group(4),
            "category": "dependency" if is_dependency_error(m.group(4)) else "syntax",
        }
        if m.group(3) == "error":
            errors.append(entry)
        else:
            warnings.append(entry)
    return errors, warnings


def main() -> None:
    java_dir = sys.argv[1] if len(sys.argv) > 1 else "outputs/04-java"
    output_file = sys.argv[2] if len(sys.argv) > 2 else "outputs/compile-result.json"

    Path(output_file).parent.mkdir(parents=True, exist_ok=True)

    def write_result(result: dict) -> None:
        with open(output_file, "w") as f:
            json.dump(result, f, indent=2)

    javac = find_javac()
    if not javac:
        result = {
            "status": "ERROR",
            "message": "javac not found. Install a JDK and ensure it is on PATH or set JAVA_HOME.",
            "file_count": 0,
            "syntax_error_count": 0,
            "missing_dependency_error_count": 0,
            "warning_count": 0,
            "errors": [],
            "warnings": [],
        }
        write_result(result)
        print("ERROR: javac not found")
        sys.exit(2)

    java_files = find_java_files(java_dir)
    if not java_files:
        result = {
            "status": "ERROR",
            "message": f"No .java files found in {java_dir}",
            "file_count": 0,
            "syntax_error_count": 0,
            "missing_dependency_error_count": 0,
            "warning_count": 0,
            "errors": [],
            "warnings": [],
        }
        write_result(result)
        print(f"ERROR: No .java files found in {java_dir}")
        sys.exit(2)

    print(f"Compiling {len(java_files)} Java file(s) with {javac}...")

    try:
        proc = subprocess.run(
            [javac, "-proc:none", "--release", "21", "-Xlint:all"] + java_files,
            capture_output=True,
            text=True,
            timeout=120,
        )
        raw_output = proc.stderr + proc.stdout
        exit_code = proc.returncode
    except subprocess.TimeoutExpired:
        result = {
            "status": "ERROR",
            "message": "javac timed out after 120 seconds",
            "file_count": len(java_files),
            "syntax_error_count": 0,
            "missing_dependency_error_count": 0,
            "warning_count": 0,
            "errors": [],
            "warnings": [],
        }
        write_result(result)
        print("ERROR: javac timed out")
        sys.exit(2)

    errors, warnings = parse_javac_output(raw_output)

    syntax_errors = [e for e in errors if e["category"] == "syntax"]
    dep_errors = [e for e in errors if e["category"] == "dependency"]

    if exit_code == 0:
        status = "PASS"
        note = ""
    elif syntax_errors:
        status = "FAIL"
        note = f"{len(syntax_errors)} syntax error(s) must be fixed before the pipeline can proceed."
    else:
        # Only dependency errors
        status = "PASS_WITH_DEPENDENCY_ERRORS"
        note = (
            f"{len(dep_errors)} error(s) are missing external dependencies "
            "(expected when compiling without Maven/Gradle and external JARs). "
            "No syntax errors found."
        )

    result = {
        "status": status,
        "file_count": len(java_files),
        "exit_code": exit_code,
        "syntax_error_count": len(syntax_errors),
        "missing_dependency_error_count": len(dep_errors),
        "warning_count": len(warnings),
        "note": note,
        "errors": errors,
        "warnings": warnings,
        "javac": javac,
    }
    write_result(result)

    if status in ("PASS", "PASS_WITH_DEPENDENCY_ERRORS"):
        print(
            f"COMPILE: {status} — {len(java_files)} file(s), "
            f"{len(syntax_errors)} syntax error(s), "
            f"{len(dep_errors)} dependency error(s), "
            f"{len(warnings)} warning(s)"
        )
        if note:
            print(f"  Note: {note}")
    else:
        print(f"COMPILE: FAIL — {len(syntax_errors)} syntax error(s) in {len(java_files)} file(s)")
        for e in syntax_errors[:20]:
            print(f"  {e['file']}:{e['line']}: {e['message']}")
        if len(syntax_errors) > 20:
            print(f"  ... and {len(syntax_errors) - 20} more (see {output_file})")
        sys.exit(1)


if __name__ == "__main__":
    main()
