#!/usr/bin/env python3
"""
C++ public interface extractor for the C++ to Java migration pipeline.

Uses Universal Ctags (preferred) or Exuberant Ctags, falling back to
regex-based parsing when neither is available.

Usage:
    python3 extract-interface.py [source_file] [output_file]

Defaults:
    source_file  = inputs/source.cpp
    output_file  = inputs/extracted-interface.json
"""

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path


def run_ctags(source_file: str) -> dict | None:
    """Try Universal Ctags (JSON output), then Exuberant Ctags (text output)."""
    ctags = shutil.which("ctags")
    if not ctags:
        return None

    # Detect Universal Ctags vs Exuberant Ctags
    try:
        version = subprocess.check_output([ctags, "--version"], text=True, timeout=5)
    except (subprocess.SubprocessError, FileNotFoundError):
        return None

    is_universal = "Universal Ctags" in version

    if is_universal:
        return _run_universal_ctags(ctags, source_file)
    else:
        return _run_exuberant_ctags(ctags, source_file)


def _run_universal_ctags(ctags: str, source_file: str) -> dict | None:
    try:
        result = subprocess.run(
            [
                ctags,
                "--output-format=json",
                "--fields=+KznS",
                "--languages=C++",
                "--kinds-C++=+pf",  # include prototypes and function definitions
                "-f", "-",
                source_file,
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        return _parse_ctags_json(result.stdout, source_file)
    except (subprocess.SubprocessError, subprocess.TimeoutExpired):
        return None


def _run_exuberant_ctags(ctags: str, source_file: str) -> dict | None:
    try:
        result = subprocess.run(
            [ctags, "-x", "--fields=+S", "--languages=C++", source_file],
            capture_output=True,
            text=True,
            timeout=30,
        )
        return _parse_ctags_text(result.stdout, source_file)
    except (subprocess.SubprocessError, subprocess.TimeoutExpired):
        return None


def _parse_ctags_json(output: str, source_file: str) -> dict:
    functions, classes, structs, enums, warnings = [], [], [], [], []
    for line in output.strip().splitlines():
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue

        kind = entry.get("kind", "")
        name = entry.get("name", "")
        line_no = entry.get("line", 0)
        signature = entry.get("signature", "")
        scope = entry.get("scope", "")

        if kind in ("function", "prototype"):
            functions.append({
                "name": name,
                "signature": f"{name}{signature}",
                "line": line_no,
                "scope": scope,
                "is_public": True,  # ctags doesn't reliably expose access; assume public
            })
        elif kind == "class":
            classes.append({"name": name, "line": line_no, "scope": scope})
        elif kind == "struct":
            structs.append({"name": name, "line": line_no, "scope": scope})
        elif kind in ("enum", "enumerator"):
            if kind == "enum":
                enums.append({"name": name, "line": line_no, "values": []})
            else:
                if enums:
                    enums[-1]["values"].append({"name": name, "line": line_no})

    return {
        "extraction_method": "universal-ctags",
        "functions": functions,
        "classes": classes,
        "structs": structs,
        "enums": enums,
        "warnings": warnings,
    }


def _parse_ctags_text(output: str, source_file: str) -> dict:
    functions, classes, structs, enums, warnings = [], [], [], [], []
    # Exuberant ctags -x format: name  kind  line  file  context
    for line in output.strip().splitlines():
        parts = line.split()
        if len(parts) < 4:
            continue
        name = parts[0]
        kind = parts[1]
        try:
            line_no = int(parts[2])
        except ValueError:
            continue

        if kind in ("function", "prototype"):
            functions.append({"name": name, "signature": name, "line": line_no, "scope": "", "is_public": True})
        elif kind == "class":
            classes.append({"name": name, "line": line_no, "scope": ""})
        elif kind == "struct":
            structs.append({"name": name, "line": line_no, "scope": ""})
        elif kind in ("enum", "enumerator"):
            enums.append({"name": name, "line": line_no, "values": []})

    if functions or classes or structs or enums:
        warnings.append("Extracted with Exuberant Ctags (no signature detail). Consider installing Universal Ctags for better accuracy.")

    return {
        "extraction_method": "exuberant-ctags",
        "functions": functions,
        "classes": classes,
        "structs": structs,
        "enums": enums,
        "warnings": warnings,
    }


def run_regex_extraction(source_file: str) -> dict:
    """
    Regex-based fallback. Handles the common cases but will miss:
    - Template specialisations with complex types
    - Macro-generated declarations
    - Functions with trailing return types (-> T)
    - Complex nested namespaces
    """
    with open(source_file, encoding="utf-8", errors="replace") as f:
        content = f.read()
        lines = content.splitlines()

    functions, classes, structs, enums, warnings = [], [], [], [], []

    # Strip single-line comments to avoid false matches
    content_no_comments = re.sub(r"//[^\n]*", "", content)
    content_no_comments = re.sub(r"/\*.*?\*/", "", content_no_comments, flags=re.DOTALL)

    # Classes
    for m in re.finditer(r"\bclass\s+(\w+)(?:\s*[:{])", content_no_comments):
        line_no = content_no_comments[: m.start()].count("\n") + 1
        classes.append({"name": m.group(1), "line": line_no, "scope": ""})

    # Structs
    for m in re.finditer(r"\bstruct\s+(\w+)(?:\s*[:{])", content_no_comments):
        line_no = content_no_comments[: m.start()].count("\n") + 1
        structs.append({"name": m.group(1), "line": line_no, "scope": ""})

    # Enums (including enum class)
    for m in re.finditer(r"\benum\s+(?:class\s+|struct\s+)?(\w+)\s*(?::\s*\w+\s*)?\{([^}]*)\}", content_no_comments, re.DOTALL):
        line_no = content_no_comments[: m.start()].count("\n") + 1
        values = [v.strip().split("=")[0].strip() for v in m.group(2).split(",") if v.strip()]
        values = [v for v in values if re.match(r"^\w+$", v)]
        enums.append({
            "name": m.group(1),
            "line": line_no,
            "values": [{"name": v, "line": 0} for v in values],
        })

    # Functions — match common patterns:
    # return_type funcname(params) [const] [override] [noexcept] [;|{]
    func_pattern = re.compile(
        r"^[ \t]*"
        r"(?:(?:virtual|static|inline|explicit|extern(?:\s+\"C\")?|constexpr)\s+)*"
        r"([\w:*&<>\s]+?)\s+"     # return type (greedy but lazy overall)
        r"(\w+)\s*"              # function name
        r"\(([^)]*)\)\s*"        # parameters
        r"(?:const\s*)?(?:override\s*)?(?:noexcept[^;{]*)?"
        r"(?:;|\{)",
        re.MULTILINE,
    )
    seen_names = set()
    for m in func_pattern.finditer(content_no_comments):
        ret_type = m.group(1).strip()
        name = m.group(2)
        params = m.group(3).strip()
        line_no = content_no_comments[: m.start()].count("\n") + 1

        # Skip common false positives
        if name in ("if", "while", "for", "switch", "return", "catch", "else"):
            continue
        if ret_type in ("return", "delete", "new"):
            continue

        key = f"{name}:{line_no}"
        if key not in seen_names:
            seen_names.add(key)
            functions.append({
                "name": name,
                "signature": f"{ret_type} {name}({params})",
                "line": line_no,
                "scope": "",
                "is_public": True,
            })

    # Flag known hard cases
    if re.search(r"template\s*<", content_no_comments):
        warnings.append("Template declarations detected — regex extraction may miss template specialisations. Manual review required.")
    if re.search(r"#define\s+\w+\([^)]*\)", content):
        warnings.append("Function-like macros detected — macro-generated declarations are not extracted. Manual review required.")
    if re.search(r'extern\s+"C"', content_no_comments):
        warnings.append('extern "C" linkage detected — check that all extern "C" functions appear in the extracted output.')
    if re.search(r"->", content_no_comments):
        warnings.append("Trailing return types (-> T) detected — these may not be captured correctly. Manual review required.")

    warnings.append(
        "Extracted with regex fallback (ctags not available). "
        "Install Universal Ctags for more accurate extraction."
    )

    return {
        "extraction_method": "regex",
        "functions": functions,
        "classes": classes,
        "structs": structs,
        "enums": enums,
        "warnings": warnings,
    }


def main() -> None:
    source_file = sys.argv[1] if len(sys.argv) > 1 else "inputs/source.cpp"
    output_file = sys.argv[2] if len(sys.argv) > 2 else "inputs/extracted-interface.json"

    if not os.path.isfile(source_file):
        print(f"ERROR: source file not found: {source_file}", file=sys.stderr)
        sys.exit(1)

    print(f"Extracting interface from {source_file}...")

    result = run_ctags(source_file)
    if result is None:
        print("ctags not available — using regex extraction (less accurate)")
        result = run_regex_extraction(source_file)
    else:
        print(f"Extraction method: {result['extraction_method']}")

    result["source_file"] = source_file

    Path(output_file).parent.mkdir(parents=True, exist_ok=True)
    with open(output_file, "w") as f:
        json.dump(result, f, indent=2)

    n_fn = len(result["functions"])
    n_cl = len(result["classes"])
    n_st = len(result["structs"])
    n_en = len(result["enums"])
    n_w = len(result["warnings"])

    print(
        f"Done: {n_fn} function(s), {n_cl} class(es), {n_st} struct(s), "
        f"{n_en} enum(s), {n_w} warning(s) → {output_file}"
    )

    if result["warnings"]:
        print("Warnings:")
        for w in result["warnings"]:
            print(f"  - {w}")


if __name__ == "__main__":
    main()
