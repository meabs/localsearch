---
name: cpp-interface-extract
description: Mechanically extracts the public interface from a C++ source file using ctags (preferred) or regex-based parsing as a fallback. Run this skill before the design agent begins analysis to produce inputs/extracted-interface.json — an authoritative, structured inventory of every public function, class, struct, and enum with line numbers and signatures. Eliminates the risk of the LLM missing macro-generated functions, extern "C" linkage, or template specialisations.
---

# C++ Interface Extractor

Use this skill at the very start of the `design` agent's run, before reading `inputs/source.cpp` manually.

## When to use
Always — as the first action in the design agent's pre-flight sequence.

## How to use

Run the extraction script:
```
python3 .github/skills/cpp-interface-extract/scripts/extract-interface.py inputs/source.cpp inputs/extracted-interface.json
```

The script will print a one-line summary of what it found and write a structured JSON file to `inputs/extracted-interface.json`.

## Reading the output

Read `inputs/extracted-interface.json` after the script completes. The file has this structure:

```json
{
  "source_file": "inputs/source.cpp",
  "extraction_method": "ctags | regex",
  "functions": [
    { "name": "processRequest", "signature": "int processRequest(const Request& r, Response& out)", "line": 42, "is_public": true }
  ],
  "classes": [
    { "name": "RequestProcessor", "line": 10, "methods": [...] }
  ],
  "structs": [
    { "name": "Request", "line": 5, "fields": [...] }
  ],
  "enums": [
    { "name": "ErrorCode", "line": 2, "values": [...] }
  ],
  "warnings": []
}
```

## Important notes

- If `extraction_method` is `regex`, flag it in the design output — regex extraction is less reliable for complex C++ (templates, macros, nested namespaces). Perform an extra manual scan of the source for any elements that look unusual.
- The `warnings` array lists any constructs the script could not parse (e.g. complex template specialisations, `#ifdef`-gated declarations). Each warning must be investigated manually.
- This file is the **authoritative** public interface inventory. The Interface Map in `outputs/01-design.md` must account for every entry in this file.
