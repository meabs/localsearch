---
name: polyglot-test-generator
description: Generates JUnit 5 unit tests for Java classes produced by the java-generation agent. Tests are driven by the traceability matrix in outputs/03-logic-validation.md — every VALIDATED row gets a test method covering its happy path, and every documented error path gets a test asserting the correct exception and error code. Tests are written to outputs/04-java-tests/ and listed in the generation manifest. Use this skill at the end of the java-generation agent's run, after all source files are complete.
---

# Polyglot Test Generator (JUnit 5 — Migration Validation)

Use this skill after all Java source files have been generated and the GENERATION-MANIFEST.md has been written. Do not run it before java-generation is complete.

## When to use
At the end of the `java-generation` agent's run, after writing `outputs/04-java/GENERATION-MANIFEST.md`.

## Goal

Generate a JUnit 5 test class for each generated Java class that:
1. Covers every happy-path behaviour documented in the traceability matrix (`VALIDATED` rows)
2. Covers every error path documented in the C++ function inventory
3. Verifies that every exception thrown carries the correct C++ error code
4. Verifies that the public interface accepts and returns the same types as the C++ equivalent
5. Uses the interface (not the implementation) wherever possible — tests should work against any correct Java implementation

## How to use

Read both files before generating any tests:
- `outputs/03-logic-validation.md` — traceability matrix (what to test)
- All Java files in `outputs/04-java/` — the classes being tested

For each class listed in `outputs/04-java/GENERATION-MANIFEST.md`:

1. Identify the corresponding traceability matrix rows for that class
2. Generate one `@Test` method per `VALIDATED` row's happy path
3. Generate one `@Test` method per documented error path (using `assertThrows`)
4. Use the JUnit 5 template from `templates/junit5-migration-test.java` as the structural base
5. Write the test file to `outputs/04-java-tests/<package-path>/<ClassName>Test.java`

## Test naming convention

```
<ClassName>Test.java
Method names: test_<cppFunctionName>_<scenario>
Examples:
  test_processRequest_happyPath()
  test_processRequest_nullInputThrowsIllegalArgumentException()
  test_processRequest_overflowThrowsArithmeticException()
```

## Required test structure per class

```java
// Header mirrors the source file header, plus:
// Test coverage for traceability rows: [row IDs]

@ExtendWith(MockitoExtension.class)
class <ClassName>Test {

    // One @Test per VALIDATED happy-path row
    @Test
    void test_<method>_<scenario>() { ... }

    // One @Test per error path
    @Test
    void test_<method>_<errorCondition>_throws<ExceptionType>WithCode<ErrorCode>() {
        var ex = assertThrows(<ExceptionType>.class, () -> ...);
        assertEquals("<cpp-error-code>", ex.getErrorCode());
    }

    // Parameterised tests for boundary values
    @ParameterizedTest
    @ValueSource(...)
    void test_<method>_boundaryValues(...) { ... }
}
```

## Traceability in test Javadoc

Every test method must have:
```java
/**
 * Covers traceability row: [LV-nnn]
 * C++ reference: <function> [source.cpp:NN-MM]
 * Business rule: BR-nnn
 */
```

## What makes a good migration test

- **Interface fidelity**: pass the same input the C++ would receive; assert the same output
- **Error code preservation**: assertThrows + assert on `getErrorCode()` — not just exception type
- **Boundary values**: test the exact integer/string boundaries the C++ uses
- **Null/absent handling**: test that Java `Optional.empty()` or `null` behaves consistently with C++ null-pointer handling
- **Enum coverage**: one test per enum value that is handled differently
- Do NOT test internal implementation details — test observable behaviour

## Output

- Test files in `outputs/04-java-tests/<package-path>/`
- Append a "Tests Generated" section to `outputs/04-java/GENERATION-MANIFEST.md`:

```markdown
## Tests Generated
| Test File | Class Under Test | Traceability Rows Covered | Test Count |
|-----------|-----------------|--------------------------|-----------|
```

## Template reference

See `templates/junit5-migration-test.java` for the structural template.
