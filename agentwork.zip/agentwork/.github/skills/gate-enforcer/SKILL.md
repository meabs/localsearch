---
name: gate-enforcer
description: Mechanically checks a pipeline output file for the [GATE FAIL] marker using grep, returning a deterministic GATE_PASS or GATE_FAIL result. Use this skill in every agent's pre-flight sequence instead of relying on the LLM to read and interpret gate status from prior outputs. Prevents false-positive gate passes caused by the LLM misreading or skimming the file.
---

# Gate Enforcer

Use this skill in every agent's pre-flight sequence to check whether prior agents passed their gates.

## When to use
Every time an agent needs to verify that a prior agent's output does not contain `[GATE FAIL]` before proceeding.

## How to use

```bash
bash .github/skills/gate-enforcer/scripts/check-gate.sh <path-to-output-file>
```

Examples:
```bash
bash .github/skills/gate-enforcer/scripts/check-gate.sh outputs/01-design.md
bash .github/skills/gate-enforcer/scripts/check-gate.sh outputs/02-security-review.md
bash .github/skills/gate-enforcer/scripts/check-gate.sh outputs/03-logic-validation.md
bash .github/skills/gate-enforcer/scripts/check-gate.sh outputs/04-java/GENERATION-MANIFEST.md
```

## Output

The script prints one of:
```
GATE_PASS: outputs/01-design.md — no gate failures found
```
or:
```
GATE_FAIL: outputs/02-security-review.md — 1 gate failure(s) found:
  [GATE FAIL — Agent 3 must not run]
  Blocking findings: SEC-001, SEC-003
```

Exit code is `0` for GATE_PASS and `1` for GATE_FAIL.

## What to do on each result

**GATE_PASS**: Continue with the agent's normal instructions.

**GATE_FAIL**: Do not continue. Write to your output file:
```
[GATE FAIL — <this agent> must not run]
Prior gate failed in <checked file>. See that file for details.
```
Then stop. Do not attempt to work around or override a GATE_FAIL — escalate to the user.

## Important notes

- Never substitute your own text-reading of the prior output file for this script check. The script is the authoritative gate result.
- If the file does not exist, the script exits with code `2` and prints `FILE_NOT_FOUND`. Treat this as GATE_FAIL and add `[PIPELINE-INTEGRITY-FAILURE]` to your output.
- Run this script for **every** prior agent's output — not just the immediately preceding one.
