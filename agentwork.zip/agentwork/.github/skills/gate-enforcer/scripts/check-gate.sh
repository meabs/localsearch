#!/usr/bin/env bash
# check-gate.sh — deterministic [GATE FAIL] detector for the C++ to Java pipeline
# Usage: bash check-gate.sh <output-file>
# Exit codes: 0 = GATE_PASS, 1 = GATE_FAIL, 2 = FILE_NOT_FOUND

set -uo pipefail

FILE="${1:-}"

if [ -z "$FILE" ]; then
    echo "Usage: check-gate.sh <output-file>" >&2
    exit 2
fi

if [ ! -f "$FILE" ]; then
    echo "FILE_NOT_FOUND: $FILE does not exist"
    exit 2
fi

MATCHES=$(grep -n "\[GATE FAIL\]" "$FILE" 2>/dev/null || true)

if [ -z "$MATCHES" ]; then
    echo "GATE_PASS: $FILE — no gate failures found"
    exit 0
else
    COUNT=$(echo "$MATCHES" | wc -l | tr -d ' ')
    echo "GATE_FAIL: $FILE — ${COUNT} gate failure(s) found:"
    echo "$MATCHES" | while IFS= read -r line; do
        echo "  $line"
    done
    exit 1
fi
