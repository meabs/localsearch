# C++ to Java Migration Pipeline — Global Instructions

## Scope
Code migration only. Hosting, deployment, infrastructure, network, and TLS configuration
are out of scope for all agents in this pipeline.

## Interface Preservation Mandate
The C++ public interface is the migration contract. Every public function, every
request/response field name, every error code must be preserved in the Java output.
Callers of the C++ code must be able to switch to Java with minimal changes.

## Input Files (place these in `inputs/` before running any agent)
| File | Description |
|------|-------------|
| `inputs/source.cpp` | The C++ file to migrate |
| `inputs/api-schema.yaml` or `inputs/api-schema.json` | API schema the Java code must call |
| `inputs/logic-document.md` | Document describing the intended business logic |

## Output Files (written by agents — do not edit manually)
| File | Written by |
|------|-----------|
| `outputs/01-design.md` | Design agent |
| `outputs/02-security-review.md` | Security review agent (code only) |
| `outputs/03-logic-validation.md` | Logic validation agent |
| `outputs/04-java/` | Java code generation agent |
| `outputs/05-pipeline-report.md` | Pipeline report agent |

## Regulated-Environment Standards
Every agent must apply these unconditionally:
- **Auditability**: every decision traceable to a specific line in source.cpp, the API schema, or the logic document
- **No silent assumptions**: flag ambiguity, state safest interpretation, never silently choose one
- **Zero data loss**: every field, constant, enum, and error code in the C++ appears in Java or has a documented reason for omission
- **Interface fidelity**: C++ public interface is the contract; Java must honour it exactly
- **Security (code only)**: OWASP Top 10 and CWE Top 25 applied to source code
- **Thread safety**: all shared state explicitly analysed
- **Input validation**: all external inputs validated at the boundary

## Agent Execution Order
```
1. design           → outputs/01-design.md
2. security-review  → outputs/02-security-review.md
3. logic-validation → outputs/03-logic-validation.md
4. java-generation  → outputs/04-java/
5. pipeline-report  → outputs/05-pipeline-report.md
```
Each agent checks for a `[GATE FAIL]` marker in the previous agent's output before proceeding.
