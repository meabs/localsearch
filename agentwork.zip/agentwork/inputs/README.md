# Inputs

Place these three files here before running the pipeline:

| File | Description |
|------|-------------|
| `source.cpp` | The C++ file to migrate |
| `api-schema.yaml` or `api-schema.json` | OpenAPI / Protobuf / custom schema that the Java code must call |
| `logic-document.md` | Document describing the intended business logic |

The pipeline will halt with `[PIPELINE HALT]` if any file is missing.
